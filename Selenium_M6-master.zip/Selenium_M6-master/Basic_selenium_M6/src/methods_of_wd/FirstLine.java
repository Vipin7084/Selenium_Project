package methods_of_wd;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

// to import go to the particular word and press
// ctrl + space => it will import the package or class or interface

public class FirstLine {
	public static void main(String[] args) throws InterruptedException {

		Thread.sleep(2000);
	
	}
}
